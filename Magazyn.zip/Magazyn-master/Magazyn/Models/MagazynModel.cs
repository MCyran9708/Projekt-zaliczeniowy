﻿using Microsoft.AspNetCore.Mvc;

namespace Magazyn.Models
{
    public class MagazynModel
    {
        public int ID { get; set; }
        public string NazwaTowaru { get; set; }
        public string Kategoria { get; set; }
        public int Ilosc { get; set; }
        public int KodKreskowy { get; set; }
        

    }
}
