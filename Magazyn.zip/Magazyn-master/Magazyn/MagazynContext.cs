﻿using Magazyn.Models;
using Microsoft.EntityFrameworkCore;

namespace Magazyn
{
    public class MagazynContext : DbContext
    {
        public DbSet<MagazynModel> Towary { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var cs = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Magazyn;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            optionsBuilder.UseSqlServer(cs);
        }
    }
}
