﻿using Magazyn.Models;
using System.Collections.Generic;
using System.Linq;

namespace Magazyn.Logic
{
    public class MagazynManager
    {
        public MagazynManager AddTowar(MagazynModel magazynModel)
        {
            using(var context = new MagazynContext())
            {
                context.Towary.Add(magazynModel);
                context.SaveChanges();                                         
            }    
            return this;
        }
        public MagazynManager RemoveTowar(int id)
        {
            using (var context = new MagazynContext())
            {
                var magazynToDelete = context.Towary.SingleOrDefault(x => x.ID == id);
                context.Towary.Remove(magazynToDelete);
                context.SaveChanges(); 
            }
            return this;
        }
        public MagazynManager UpdateTowar(MagazynModel magazynModel)
        {
            using (var context = new MagazynContext())
            {
                context.Towary.Update(magazynModel);
                context.SaveChanges(); 
            }
            return this;
        }
        public MagazynModel GetTowary(int id)
        {
            using (var context = new MagazynContext())
            {
              var towar = context.Towary.Single(x => x.ID == id);
                return towar;
            }
            
        }
        public List<MagazynModel> GetTowary()
        {
            using (var context = new MagazynContext())
            {
                var magazynList = context.Towary.ToList();
                return magazynList;
            }
            
        }
    }
}
