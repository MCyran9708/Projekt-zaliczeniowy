﻿using Magazyn.Logic;
using Magazyn.Models;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Collections.Generic;

namespace Magazyn.Controllers
{
    public class MagazynController : Controller
    {
        MagazynManager magazynManager = new MagazynManager();
        public IActionResult Index(MagazynManager magazynManager)
        {
            var list = magazynManager.GetTowary();
            return View(list);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(MagazynModel magazynModel)
        {
            magazynManager.AddTowar(magazynModel);
            return RedirectToAction("Index");
        }
        [HttpGet]  
        public IActionResult Remove(int id) 
        {
            var towar = magazynManager.GetTowary(id);  
            return View(towar);
        }
        [HttpPost]
        public IActionResult RemoveConfirm(int id)
        {
            magazynManager.RemoveTowar(id);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit (int id)
        {
            var towar = magazynManager.GetTowary(id);
            return View(towar); 
        }
        [HttpPost]
        public IActionResult Edit (MagazynModel magazynModel)
        {
            magazynManager.UpdateTowar(magazynModel);
            return RedirectToAction("Index");
        }
    }
}
